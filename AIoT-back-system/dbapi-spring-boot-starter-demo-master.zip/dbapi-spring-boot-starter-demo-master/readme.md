## 概述

[dbapi-spring-boot-starter](https://gitee.com/freakchicken/dbapi-spring-boot-starter) 框架的使用案例代码

<p align="center">
	👉 <a target="_blank" href="https://starter.51dbapi.com">https://starter.51dbapi.com</a>  👈
</p>

## maven依赖
```xml
<dependency>
    <groupId>com.gitee.freakchicken</groupId>
    <artifactId>dbapi-spring-boot-starter</artifactId>
    <version>1.1.0</version>
</dependency>

```